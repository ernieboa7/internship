'''
PYTHON WORKSHEET

1. Which of the following operators is used to calculate remainder in a division?
Answer C) % 

2. In python 2//3 is equal to?
Answer B) 0

3. In python, 6<<2 is equal to?
Answer C) 24 

4. In python, 6&2 will give which of the following as output?
Answer A) 2 

5. In python, 6|2 will give which of the following as output?
Answer D) 6

6. What does the finally keyword denotes in python?
Answer C) the finally block will be executed no matter if the try block raises an error or not.

7. What does raise keyword is used for in python?
Answer A) It is used to raise an exception. 

8. Which of the following is a common use case of yield keyword in python?
Answer C) in defining a generator 


Q9 and Q10 have multiple correct answers. Choose all the correct options to answer your question.

9. Which of the following are the valid variable names?
Answer A) _abc and C) abc2 

10. Which of the following are the keywords in python?
Answer A) yield B) raise



'''
# 11
def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n-1)

print(factorial(8))

# 12
def is_prime(n):
    if n <= 1:
        return False
    elif n == 2:
        return True
    elif n % 2 == 0:
        return False

    i = 3
    while i*i <= n:
        if n % i == 0:
            return False
        i += 2

    return True

n= int(input('type a number :'))
if is_prime(n):
    print(n, "is a prime number.")
else:
    print(n, "is a composite number.")


# 13
def is_palindrome(string):
    # Convert the string to lowercase and remove whitespace
    string = string.lower().replace(" ", "")
    
    # Reverse the string
    reversed_string = string[::-1]
    
    # Check if the string and its reverse are equal
    if string == reversed_string:
        return True
    else:
        return False

string = input("Enter a string: ")

if is_palindrome(string):
    print("This string is a palindrome.")
else:
    print("This string is not a palindrome.")
    

# 14
import math

def get_third_side(side1, side2):
    # Calculate the square of each side
    side1_squared = side1 ** 2
    side2_squared = side2 ** 2
    
    # Calculate the square root of the sum of squares
    third_side = math.sqrt(side1_squared + side2_squared)
    
    return third_side

# Get user input for the lengths of two sides
side1 = float(input("Enter the length of the first side: "))
side2 = float(input("Enter the length of the second side: "))

# Calculate the length of the third side
third_side = get_third_side(side1, side2)

print("The length of the third side is:", third_side)

# 15
def character_frequency(string):
    # Create an empty dictionary to store character frequencies
    frequency = {}
    
    # Iterate over each character in the string
    for char in string:
        # Increment the count for each character
        frequency[char] = frequency.get(char, 0) + 1
    
    # Print the character frequencies
    for char, count in frequency.items():
        print(f"Character '{char}' appears {count} time(s)")

# Get user input
string = input("Enter a string: ")

# Call the function to calculate character frequencies
character_frequency(string)

    
